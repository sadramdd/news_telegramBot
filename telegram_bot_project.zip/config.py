import os 

DB_pass = os.environ.get("db_password", 'jmeXPJ$SFgYYlta3n22x')
DB_host = os.environ.get("db_host", "khabarresandb-qqp-service")
DB_user = os.environ.get('user', "root")
DB_name = os.environ.get('db_name', "khabarreiqg_db")

DB_CONFIG = {"password": DB_pass, "host": DB_host, "user": DB_user}

BOTTOKEN = os.environ.get("token","8183611416:AAGr8VABhUDrfBXqgUxX7iiHeNBguOvDFdI")

topics = eval(os.environ.get("topics", '["جهان", "فرهنگی و هنری", "استان ها", "اقتصادی","ایسنا+","ورزشی", "اجتماعی", "علمی  و دانشگاهی", "سیاسی"]'))


RSS_URL = os.environ.get("rss", 'https://www.isna.ir/rss')


log_file = os.environ.get('logfile', "project.log")

spam_rate = int(os.environ.get("spam_rate", "20"))

spam_time_rate = int(os.environ.get("spam_time_rate" ,"1"))